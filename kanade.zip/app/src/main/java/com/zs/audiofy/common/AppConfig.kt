package com.zs.audiofy.common

import android.os.Build
import android.util.Log
import androidx.compose.runtime.Stable
import com.zs.audiofy.common.AppConfig.KEYS_DELIMITER
import com.zs.audiofy.common.AppConfig.RECORD_DELIMITER
import com.zs.audiofy.common.AppConfig.isBackgroundBlurEnabled
import com.zs.audiofy.common.AppConfig.isLoadThumbnailFromCache
import com.zs.audiofy.common.AppConfig.stringify

/**
 * Singleton object for managing application-wide configuration settings.
 *
 * `AppConfig` provides a centralized repository for settings that can be dynamically
 * modified during runtime. Some changes may necessitate an application restart.
 *
 * Initialization occurs at application startup via the [update] method.
 * Configuration values can be modified through the application's settings interface.
 *
 * This object handles default values and configurations not directly managed
 * by Jetpack Compose, ensuring a clear separation of concerns for global settings.
 *
 * @author Zakir Sheikh
 * @since 1.0.0
 */
@Stable
object AppConfig {

    private const val TAG = "AppConfig"

    //
    var APPLICATION_ID: String = ""
        private set
    var VERSION_CODE: Int = -1
        private set
    var VERSION_NAME = ""
        private set

    /** Determines if media thumbnails should be loaded from the cache. */
    @JvmField
    var isLoadThumbnailFromCache: Boolean = false

    /** Get/Set strategy enable background blur. */
    @JvmField
    var isBackgroundBlurEnabled: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    /** Determines if the trash can feature for deleted media is enabled. */
    @JvmField
    var isTrashCanEnabled: Boolean = true

    /** Specifies the font scaling factor for the application. -1f indicates system default. */
    @JvmField
    var fontScale: Float = -1f

    /** Minimum duration in seconds for a track to be considered valid or displayed. */
    @JvmField
    var minTrackLengthSecs: Int = 30

    /** Indicates whether to use the system's built-in audio effects. */
    @JvmField
    var inAppAudioEffectsEnabled: Boolean = true

    /** Multiplier for adjusting the size of items in grid layouts. */
    @JvmField
    var gridItemSizeMultiplier: Float = 1.0f

    /**
     * Determines FAB player long press action.
     * `true`: launch [com.zs.audiofy.console.Console].
     * `false`: launch in-app widget. Defaults to `true`.
     */
    @JvmField
    var fabLongPressLaunchConsole = true

    /**
     * Toggles between SurfaceView and TextureView for video rendering.
     * `true` enables SurfaceView, `false` enables TextureView. Defaults to `true`.
     */
    @JvmField
    var isSurfaceViewVideoRenderingPreferred = true

    /**
     * Controls whether files displayed in directories (e.g., playlist members, audio files,
     * video files, artist-specific files) are grouped.
     *
     * When `true` (default), files within these directory views will be organized into
     * groups, potentially based on criteria like album, artist, or folder structure.
     * This can enhance readability and navigation for large collections.
     *
     * When `false`, files will be displayed as a flat list without any grouping,
     * which might be preferred for smaller collections or specific user preferences.
     */
    @JvmField
    var isFileGroupingEnabled = true

    /**
     * If true, shows a launch console button in the in-app widget; otherwise, another media action is shown,
     * and the console can only be opened from the compact (FAB) player.
     */
    @JvmField
    var showInAppWidgetOpenConsoleButton = true

    /**
     * If true, long-pressing the in-app widget opens its config instead of showing the config button.
     */
    @JvmField
    var inAppWidgetLongPressOpenConfig = false

    /** If true, waits for the splash screen animation to finish before proceeding.  */
    @JvmField
    var isSplashAnimWaitEnabled = false

    /**
     * Enables or disables the smooth transition animation when launching the
     * [Console][com.zs.audiofy.console.Console] from the in-app widget.
     */
    @JvmField
    var isWidgetToConsoleTransitionEnabled = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    /**
     * Enables or disables labs mode. Labs mode enables or disables features that are in preview/beta mode
     */
    @JvmField
    var isLabsModeOn = false

    // Delimiters
    private const val KEYS_DELIMITER = '\u001E'
    private const val RECORD_DELIMITER = ':'

    // Keys
    private const val KEY_LOAD_THUMB_FROM_CACHE = "param1"
    private const val KEY_BACKGROUND_BLUR_ENABLED = "param2"
    private const val KEY_TRASH_CAN_ENABLED = "param3"
    private const val KEY_FONT_SCALE = "param4"
    private const val KEY_MIN_TRACK_LENGTH_SECS = "param5"
    private const val KEY_USE_SYSTEM_AUDIO_FX = "param6"
    private const val KEY_GRID_ITEM_SIZE_MULTIPLIER = "param7"
    private const val KEY_FAB_LONG_PRESS_LAUNCH_CONSOLE = "param8"
    private const val KEY_SURFACE_VIEW_VIDEO_RENDERING_PREFERRED = "param9"
    private const val KEY_FILE_GROUPING_ENABLED = "param10"
    private const val KEY_SHOW_INAPP_WIDGET_DEDICATED_OPEN_CONSOLE_BTN = "param11"
    private const val KEY_INAPP_WIDGET_LONG_PRESS_OPEN_CONFIG = "param12"
    private const val KEY_IS_SPLASH_ANIM_WAIT_ENABLED = "param13"
    private const val KEY_IS_WIDGET_TO_CONSOLE_TRANSITION_ENABLED = "param14"
    private const val KEY_IS_LABS_MODE_ON = "param15"


    /**
     * Appends a single key-value record to the given [StringBuilder].
     *
     * This operator function facilitates the construction of a serialized string
     * representing application configuration. It appends the provided `key` and `value`
     * to the `StringBuilder`, separated by [RECORD_DELIMITER] and followed by
     * [KEYS_DELIMITER].
     *
     * Example usage: `stringBuilder["myKey"] = "myValue"` results in `myKey:myValue\u001E` being appended.
     *
     * @param T The type of the value. Must be a simple type (String, Int, Boolean, Float, Long).
     * @param key The key for the configuration setting.
     * @param value The value of the configuration setting.
     * @throws IllegalArgumentException if the provided value type `T` is not supported.
     */
    @Throws(IllegalArgumentException::class)
    private inline operator fun <reified T> StringBuilder.set(key: String, value: T) {
        when (T::class) {
            // append key, separator, value, and record delimiter in a single call chain
            String::class, Int::class, Boolean::class, Float::class, Long::class -> {
                append(key)
                append(RECORD_DELIMITER)
                append(value)
                append(KEYS_DELIMITER)
            }

            else -> throw IllegalArgumentException("Unsupported type: ${T::class}")
        }
    }

    /**
     * Serializes the current configuration into a string format.
     *
     * This method converts the application's current settings, such as
     * [isLoadThumbnailFromCache] and [isBackgroundBlurEnabled], into a
     * single string. Each setting is represented as a key-value pair,
     * delimited by [RECORD_DELIMITER], and multiple settings are separated
     * by [KEYS_DELIMITER].
     *
     * The resulting string can be used for persisting the configuration or
     * transmitting it. It can be later parsed by the [update] method to
     * restore the configuration.
     *
     * @return A string representation of the current application configuration.
     *         Example: "param1:true␞param2:false␞"
     */
    fun stringify(): String {
        val records = StringBuilder()
        records[KEY_LOAD_THUMB_FROM_CACHE] = isLoadThumbnailFromCache
        records[KEY_BACKGROUND_BLUR_ENABLED] = isBackgroundBlurEnabled
        records[KEY_TRASH_CAN_ENABLED] = isTrashCanEnabled
        records[KEY_FONT_SCALE] = fontScale
        records[KEY_MIN_TRACK_LENGTH_SECS] = minTrackLengthSecs
        records[KEY_USE_SYSTEM_AUDIO_FX] = inAppAudioEffectsEnabled
        records[KEY_GRID_ITEM_SIZE_MULTIPLIER] = gridItemSizeMultiplier
        records[KEY_FAB_LONG_PRESS_LAUNCH_CONSOLE] = fabLongPressLaunchConsole
        records[KEY_SURFACE_VIEW_VIDEO_RENDERING_PREFERRED] = isSurfaceViewVideoRenderingPreferred
        records[KEY_FILE_GROUPING_ENABLED] = isFileGroupingEnabled
        records[KEY_SHOW_INAPP_WIDGET_DEDICATED_OPEN_CONSOLE_BTN] = showInAppWidgetOpenConsoleButton
        records[KEY_INAPP_WIDGET_LONG_PRESS_OPEN_CONFIG] = inAppWidgetLongPressOpenConfig
        records[KEY_IS_SPLASH_ANIM_WAIT_ENABLED] = isSplashAnimWaitEnabled
        records[KEY_IS_WIDGET_TO_CONSOLE_TRANSITION_ENABLED] = isWidgetToConsoleTransitionEnabled
        records[KEY_IS_LABS_MODE_ON] = isLabsModeOn
        Log.i(TAG, "stringify: $records")
        return records.toString()
    }

    /**
     * Initializes the application configuration and updates settings from a serialized string.
     *
     * This operator function sets the core application metadata and parses the [encoded]
     * string to restore persisted configuration values. The string is expected to contain
     * key-value pairs separated by [RECORD_DELIMITER] and [KEYS_DELIMITER].
     *
     * @param appID The unique application identifier (e.g., package name).
     * @param versionCode The integer version code of the application.
     * @param versionName The user-visible version name string.
     */
    operator fun invoke(
        appID: String,
        versionCode: Int,
        versionName: String,
        encoded: String? = null
    ) {
        APPLICATION_ID = appID
        VERSION_CODE = versionCode
        VERSION_NAME = versionName
        Log.i(TAG, "update: $appID, $versionCode, $versionName")
        if (encoded == null) return
        Log.i(TAG, "update: $")
        val records = encoded.split(KEYS_DELIMITER).filter { it.isNotEmpty() }
        for (record in records) {
            Log.i(TAG, "record: $record")
            val sepIndex = record.indexOf(RECORD_DELIMITER)
            if (sepIndex <= 0) continue

            val key = record.substring(0, sepIndex)
            val value = record.substring(sepIndex + 1)
            when (key) {
                KEY_LOAD_THUMB_FROM_CACHE -> isLoadThumbnailFromCache = value.toBoolean()
                KEY_BACKGROUND_BLUR_ENABLED -> isBackgroundBlurEnabled = value.toBoolean()
                KEY_TRASH_CAN_ENABLED -> isTrashCanEnabled = value.toBoolean()
                KEY_FONT_SCALE -> fontScale = value.toFloat()
                KEY_MIN_TRACK_LENGTH_SECS -> minTrackLengthSecs = value.toInt()
                KEY_USE_SYSTEM_AUDIO_FX -> inAppAudioEffectsEnabled = value.toBoolean()
                KEY_GRID_ITEM_SIZE_MULTIPLIER -> gridItemSizeMultiplier = value.toFloat()
                KEY_FAB_LONG_PRESS_LAUNCH_CONSOLE -> fabLongPressLaunchConsole = value.toBoolean()
                KEY_SURFACE_VIEW_VIDEO_RENDERING_PREFERRED -> isSurfaceViewVideoRenderingPreferred =
                    value.toBoolean()

                KEY_FILE_GROUPING_ENABLED -> isFileGroupingEnabled = value.toBoolean()
                KEY_INAPP_WIDGET_LONG_PRESS_OPEN_CONFIG -> inAppWidgetLongPressOpenConfig =
                    value.toBoolean()

                KEY_SHOW_INAPP_WIDGET_DEDICATED_OPEN_CONSOLE_BTN -> showInAppWidgetOpenConsoleButton =
                    value.toBoolean()

                KEY_IS_SPLASH_ANIM_WAIT_ENABLED -> isSplashAnimWaitEnabled = value.toBoolean()
                KEY_IS_WIDGET_TO_CONSOLE_TRANSITION_ENABLED -> isWidgetToConsoleTransitionEnabled =
                    value.toBoolean()

                KEY_IS_LABS_MODE_ON -> isLabsModeOn = value.toBoolean()
            }
        }
    }
}