/*
 *  Copyright (c) 2025 Zakir Sheikh
 *
 *  Created by Zakir Sheikh on $today.date.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package com.zs.audiofy.console

import android.view.Gravity
import androidx.annotation.FloatRange
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.zs.audiofy.R
import com.zs.audiofy.common.Res
import com.zs.audiofy.common.compose.emit
import com.zs.audiofy.common.ellipsize
import com.zs.audiofy.common.vectorResource
import com.zs.compose.foundation.fadingEdge
import com.zs.compose.foundation.textResource
import com.zs.compose.theme.AlertDialog
import com.zs.compose.theme.AppTheme
import com.zs.compose.theme.ButtonDefaults
import com.zs.compose.theme.Chip
import com.zs.compose.theme.ChipDefaults
import com.zs.compose.theme.ContentAlpha
import com.zs.compose.theme.Icon
import com.zs.compose.theme.IconButton
import com.zs.compose.theme.LocalContentColor
import com.zs.compose.theme.LocalWindowSize
import com.zs.compose.theme.RadioButton
import com.zs.compose.theme.SelectableChip
import com.zs.compose.theme.Slider
import com.zs.compose.theme.text.Header
import com.zs.compose.theme.text.Label
import com.zs.compose.theme.text.Text
import com.zs.core.playback.Remote
import com.zs.core.playback.Remote.TrackInfo
import kotlin.math.roundToInt
import com.zs.audiofy.common.compose.ContentPadding as CP

private val CustomWidthProperties = DialogProperties(usePlatformDefaultWidth = false)
private val SPEED_RANGE = 0.25f..8.0f
private const val REQUEST_DISMISS = -1.0f

private val PLAYBACK_SPEED_PRESETS =
    floatArrayOf(0.9f, 0.95f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f)

/**
 * Represents the playback speed dialog.
 * @param onRequestChange Called when the playback speed is changed. -1; dismiss the dialog.
 */
@Composable
fun PlaybackSpeed(
    expanded: Boolean,
    @FloatRange(0.25, 8.0) value: Float,
    onRequestChange: (value: Float) -> Unit
) {
    if (!expanded)
        return
    val onDismissRequest = { onRequestChange(REQUEST_DISMISS) }
    val (width, height) = LocalWindowSize.current
    //
    val step = 0.05f
    AlertDialog(
        onDismissRequest = onDismissRequest,
        properties = CustomWidthProperties,
        gravity = if (width > height) Gravity.CENTER else Gravity.BOTTOM,
        title = {
            Label(
                textResource(Res.string.scr_playback_speed_title),
                fontWeight = FontWeight.Light
            )
        },
        navigationIcon = {
            IconButton(
                icon = vectorResource(Res.drawable.ic_close_filled),
                contentDescription = null,
                onClick = onDismissRequest
            )
        },
        content = {
            val (speed, onValueChange) = remember { mutableFloatStateOf(value) }
            // Slider to change the playback speed.
            // Preview
            Label(
                text = textResource(Res.string.scale_factor_f, speed),
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = AppTheme.typography.display3
            )
            val colors = AppTheme.colors
            val isLight = colors.isLight
            // Controls
            val chipColors = ChipDefaults.chipColors(
                backgroundColor = if (isLight) colors.background(8.dp) else colors.onBackground.copy(
                    ContentAlpha.indication
                ),
                contentColor = AppTheme.colors.onBackground
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Decrease
                Chip(
                    content = { Icon(vectorResource(Res.drawable.ic_remove), contentDescription = null) },
                    colors = chipColors,
                    border = ChipDefaults.outlinedBorder,
                    onClick = {
                        val newValue =
                            (speed - step).coerceAtLeast(SPEED_RANGE.start)
                        onValueChange(newValue)
                        onRequestChange(newValue)
                    },
                )

                // Slider
                Slider(
                    value = speed,
                    onValueChange = {
                        val newValue = (it / step).roundToInt() * step
                        onValueChange(newValue)
                    },
                    onValueChangeFinished = { onRequestChange(speed) },
                    valueRange = SPEED_RANGE,
                    modifier = Modifier.weight(1f)
                )

                // Increase
                Chip(
                    content = { Icon(vectorResource(Res.drawable.ic_add), contentDescription = null) },
                    colors = chipColors,
                    border = ChipDefaults.outlinedBorder,
                    onClick = {
                        val newValue =
                            (speed + step).coerceAtMost(SPEED_RANGE.endInclusive)
                        onValueChange(newValue)
                        onRequestChange(newValue)
                    },
                )
            }
            // Presets
            Header(stringResource(Res.string.presets), style = AppTheme.typography.label3)
            val presetsScrollState = rememberScrollState()
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = CP.SmallArrangement,
                modifier = Modifier
                    .fadingEdge(presetsScrollState, true, 15.dp)
                    .horizontalScroll(presetsScrollState),
                content = {
                    val padding = Modifier.padding(horizontal = CP.small)
                    for (value in PLAYBACK_SPEED_PRESETS) {
                        Chip(
                            colors = chipColors,
                            border = ChipDefaults.outlinedBorder,
                            content = {
                                Label(
                                    text = textResource(
                                        Res.string.scale_factor_f,
                                        value
                                    ), modifier = padding
                                )
                            },
                            onClick = {
                                onRequestChange(value);
                                onValueChange(value)
                            },
                        )
                    }
                }
            )
        }
    )
}

private val TIMER_RANGE = 10f..120f
private const val TIMER_INCREMENT = 10f

/**
 * Represents the sleep timer dialog.
 */
@Composable
fun SleepTimer(
    expanded: Boolean,
    onRequestChange: (mills: Long) -> Unit
) {
    if (!expanded) return
    val (width, height) = LocalWindowSize.current
    val onDismissRequest = { onRequestChange(-1) }
    val (mins, onTimerChange) = remember { mutableFloatStateOf(TIMER_RANGE.start) }
    AlertDialog(
        onDismissRequest = onDismissRequest,
        properties = CustomWidthProperties,
        gravity = if (width > height) Gravity.CENTER else Gravity.BOTTOM,
        navigationIcon = {
            IconButton(
                icon = vectorResource(Res.drawable.ic_close_filled),
                contentDescription = null,
                onClick = onDismissRequest
            )
        },
        title = {
            Label(textResource(Res.string.scr_sleep_timer_title), fontWeight = FontWeight.Light)
        },
        actions = {
            // Start Timer
            val color = LocalContentColor.current
            Chip(
                modifier = Modifier.padding(end = CP.small),
                colors = ChipDefaults.chipColors(
                    backgroundColor = color.copy(ContentAlpha.indication),
                    contentColor = color
                ),
                onClick = { onRequestChange(mins.toLong() * 60_000) }) {
                Label(stringResource(Res.string.start).uppercase())
            }
        },
        content = {

            // Preview
            Label(
                text = textResource(Res.string.scr_sleep_timer_minute_d, mins.roundToInt()),
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = AppTheme.typography.title1
            )

            val colors = AppTheme.colors
            val isLight = colors.isLight
            // Controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = CP.SmallArrangement
            ) {
                val chipColors = ChipDefaults.chipColors(
                    backgroundColor = if (isLight) colors.background(6.dp) else colors.onBackground.copy(
                        ContentAlpha.indication
                    ),
                    contentColor = colors.onBackground
                )
                // Decrease
                Chip(
                    content = { Icon(vectorResource(Res.drawable.ic_remove), contentDescription = null) },
                    colors = chipColors,
                    border = ChipDefaults.outlinedBorder,
                    onClick = {
                        val newValue = (mins - TIMER_INCREMENT).coerceAtLeast(TIMER_RANGE.start)
                        onTimerChange(newValue)
                    },
                )
                // Slider
                Slider(
                    value = mins,
                    onValueChange = onTimerChange,
                    valueRange = TIMER_RANGE,
                    steps = 10,
                    modifier = Modifier.weight(1f)
                )

                // Increase
                Chip(
                    content = { Icon(vectorResource(Res.drawable.ic_add), contentDescription = null) },
                    colors = chipColors,
                    border = ChipDefaults.outlinedBorder,
                    onClick = {
                        val newValue =
                            (mins + TIMER_INCREMENT).coerceAtMost(TIMER_RANGE.endInclusive)
                        onTimerChange(newValue)
                    },
                )
            }
        }
    )
}


/**
 * A dialog that allows the user to configure media tracks (audio and video).
 *
 * @param viewState The current state of the console view.
 * @param onDismissRequest A callback that is invoked when the dialog is dismissed.
 */
@Composable
fun MediaConfigDialog(
    viewState: ConsoleViewState,
    onDismissRequest: () -> Unit
) {
    val (width, height) = LocalWindowSize.current
    AlertDialog(
        onDismissRequest = onDismissRequest,
        properties = CustomWidthProperties,
        gravity = if (width > height) Gravity.CENTER else Gravity.BOTTOM,
        navigationIcon = {
            IconButton(
                icon = vectorResource(Res.drawable.ic_close_filled),
                contentDescription = null,
                onClick = onDismissRequest
            )
        },
        title = {
            Text(
                text = textResource(id = Res.string.scr_media_config_title),
                fontWeight = FontWeight.Light,
                lineHeight = 23.sp,
            )
        },
        content = {
            var checked by remember { mutableIntStateOf(Remote.TRACK_TYPE_AUDIO) }
            Header(
                "Choose Audio, Video & Subtitles",
                style = AppTheme.typography.title3,
                color = AppTheme.colors.accent,
                drawDivider = true,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Audio
                val spacer = Modifier.offset(x = -CP.xSmall)
                RadioButton(
                    selected = checked == Remote.TRACK_TYPE_AUDIO,
                    onValueChange = {
                        checked = Remote.TRACK_TYPE_AUDIO
                    }
                )

                val style = AppTheme.typography.label3
                Label(stringResource(Res.string.audio), modifier = spacer, style = style)

                // Video
                RadioButton(
                    selected = checked == Remote.TRACK_TYPE_VIDEO,
                    onValueChange = {
                        checked = Remote.TRACK_TYPE_VIDEO
                    }
                )

                Label(stringResource(Res.string.video), modifier = spacer, style = style)

                // Subtitle
                RadioButton(
                    selected = checked == Remote.TRACK_TYPE_TEXT,
                    onValueChange = {
                        checked = Remote.TRACK_TYPE_TEXT
                    }
                )

                Label(stringResource(Res.string.subtitle),  style = style)
            }

            val colors = ChipDefaults.selectableChipColors()
            // Audio Tracks
            val tracks: List<TrackInfo>? by produceState(null, checked) {
                value = viewState.getAvailableTracks(checked)
            }
            val checkedTrack: TrackInfo? by produceState(null, checked) {
                value = viewState.getCheckedTrack(checked)
            }

            LazyRow(
                horizontalArrangement = CP.SmallArrangement,
                verticalAlignment = Alignment.CenterVertically,
                content = {
                    val data = emit(false, tracks) ?: return@LazyRow

                    // subtitle allows selection none.
                    if (checked == Remote.TRACK_TYPE_TEXT)
                        item(
                            content = {
                                val selected  = checkedTrack ==  null
                                SelectableChip(
                                    selected,
                                    colors = colors,
                                    border = if (selected) ChipDefaults.outlinedBorder else ButtonDefaults.outlinedBorder,
                                    leadingIcon = {
                                        Icon(
                                            vectorResource(Res.drawable.ic_audio_file),
                                            contentDescription = null
                                        )
                                    },
                                    content = { Label(stringResource(Res.string.none)) },
                                    onClick = {
                                        viewState.setCheckedTrack(
                                            Remote.TRACK_TYPE_TEXT,
                                            null
                                        )
                                        onDismissRequest()
                                    },
                                    modifier = Modifier.animateItem()
                                )
                            }
                        )

                    items(
                        items = data,
                        itemContent = {
                            val selected  = checkedTrack?.name == it.name
                            SelectableChip(
                                selected,
                                colors = colors,
                                border = if (selected) ChipDefaults.outlinedBorder else ButtonDefaults.outlinedBorder,
                                leadingIcon = {
                                    Icon(
                                        vectorResource(Res.drawable.ic_audio_file),
                                        contentDescription = null
                                    )
                                },
                                content = { Label(it.name.ellipsize(25)) },
                                onClick = {
                                    viewState.setCheckedTrack(checked, it)
                                    onDismissRequest()
                                },
                                modifier = Modifier.animateItem()
                            )
                        }
                    )
                }
            )
        }
    )
}